#ifndef _event_h_
#define _event_h_

#include "jbluetooth.h"

/************************************************************************

  This is the event driven (non blocking) bluetooth API for Mac OS X.

  This is implemented on top of the blocking API (blbtapi). These two
  together are the implemtation of the bluetooth API (btapi).

 ************************************************************************/

int event_init(void);

int event_destroy(void);

int event_startInquiry(int accessCode, DiscoveryListener listener);

int event_cancelInquiry(DiscoveryListener listener);

#endif
