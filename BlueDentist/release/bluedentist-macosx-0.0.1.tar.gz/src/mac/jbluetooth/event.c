#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>

#include "jbluetooth.h"
#include "event.h"
#include "block.h"


static pthread_t worker;
static pthread_mutex_t shared_data_lock;
static pthread_mutex_t sleep_lock;
static pthread_cond_t sleep_cond;

static int worker_stay_alive = JBLUETOOTH_TRUE;
static int worker_has_work = JBLUETOOTH_FALSE;
static int shared_accessCode;
static DiscoveryListener shared_listener;


static int create_locks() {
	int success = JBLUETOOTH_TRUE;
	int ret = 0;

	ret = pthread_mutex_init(&shared_data_lock, NULL);
	if(ret != 0) {
		perror("create data lock");
		success = JBLUETOOTH_FALSE;
	}

	ret = pthread_mutex_init(&sleep_lock, NULL);
	if(ret != 0) {
		perror("create sleep lock");
		success = JBLUETOOTH_FALSE;
	}

	ret = pthread_mutex_lock(&sleep_lock);
	if(ret != 0) {
		perror("lock sleep lock");
		success = JBLUETOOTH_FALSE;
	}

	ret = pthread_cond_init(&sleep_cond, NULL);
	if(ret != 0) {
		perror("create sleep cond");
		success = JBLUETOOTH_FALSE;
	}

	return success;
}


static int destroy_locks() {
	int success = JBLUETOOTH_TRUE;
	int ret = 0;
	
	ret = pthread_mutex_destroy(&shared_data_lock);
	if(ret != 0) {
		perror("destroy shared data lock");
		success = JBLUETOOTH_FALSE;
	}

	ret = pthread_cond_destroy(&sleep_cond);
	if(ret != 0) {
		perror("destroy sleep cond");
		success = JBLUETOOTH_FALSE;
	}

	ret = pthread_mutex_unlock(&sleep_lock);
	if(ret != 0) {
		perror("unlock sleep lock");
		success = JBLUETOOTH_FALSE;
	}

	ret = pthread_mutex_destroy(&sleep_lock);
	if(ret != 0) {
		perror("destroy sleep lock");
		success = JBLUETOOTH_FALSE;
	}

	return success;
}


static int obtain_data_lock() {
	int success = JBLUETOOTH_TRUE;
	int ret = 0;

	ret = pthread_mutex_lock(&shared_data_lock);
	if(ret != 0) {
		perror("obtain lock");
		success = JBLUETOOTH_FALSE;
	}

	return success;
}


static int release_data_lock() {
	int success = JBLUETOOTH_TRUE;
	int ret = 0;

	ret = pthread_mutex_unlock(&shared_data_lock);
	if(ret != 0) {
		perror("release lock");
		success = JBLUETOOTH_FALSE;
	}

	return success;
}


static int worker_setupInquiry() {
	int success = JBLUETOOTH_TRUE;
	int status = JBLUETOOTH_TRUE;

	if(success == JBLUETOOTH_TRUE) {
		status = block_setupInquiry(shared_accessCode, shared_listener);
		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "Problems setting up inquiry!\n");
			success = JBLUETOOTH_FALSE;
		}
	}

	return success;
}


static int wake_worker() {
	int success = JBLUETOOTH_TRUE;
	int ret = 0;

	worker_has_work = JBLUETOOTH_TRUE;

	ret = pthread_cond_signal(&sleep_cond);
	if(ret != 0) {
		perror("signal worker");
		success = JBLUETOOTH_FALSE;
	}

	return success;
}


static int wait_for_work() {
	int success = JBLUETOOTH_TRUE;
	int ret = 0;


	while(worker_has_work != JBLUETOOTH_TRUE
		|| success != JBLUETOOTH_TRUE) {
		ret = pthread_cond_wait(&sleep_cond, &sleep_lock);
		if(ret != 0) {
			fprintf(stderr, "Could not wait for signal!\n");
			success = JBLUETOOTH_FALSE;
		}
	}

	if(success == JBLUETOOTH_TRUE) {
		worker_has_work = JBLUETOOTH_FALSE;
	}

	return success;
}


static int workerCode(void) {
	int success = JBLUETOOTH_TRUE;
	int status = JBLUETOOTH_TRUE;


	while(worker_stay_alive == JBLUETOOTH_TRUE) {
		int got_lock = JBLUETOOTH_FALSE;

		status = wait_for_work();
		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "Worker failed to wait for work!\n");
			success = JBLUETOOTH_FALSE;
		}

		if(worker_stay_alive == JBLUETOOTH_TRUE && success == JBLUETOOTH_TRUE) {
			status = obtain_data_lock();
			if(status != JBLUETOOTH_TRUE) {
				fprintf(stderr, "Worker could not obtain lock!\n");
				success = JBLUETOOTH_FALSE;
			} else {
				got_lock = JBLUETOOTH_TRUE;
			}
		}

		if(worker_stay_alive == JBLUETOOTH_TRUE && success == TRUE) {
			status = worker_setupInquiry();
			if(status != JBLUETOOTH_TRUE) {
				fprintf(stderr, "Worker has problems initializing inquiry!\n");
				success = JBLUETOOTH_FALSE;
			}
		}

		if(got_lock == JBLUETOOTH_TRUE) {
			status = release_data_lock();
			if(status != JBLUETOOTH_TRUE) {
				fprintf(stderr, "Worker could not release lock!\n");
				success = JBLUETOOTH_FALSE;
			}
		}

		if(worker_stay_alive == JBLUETOOTH_TRUE && success == JBLUETOOTH_TRUE) {
			status = block_doInquiry();
			if(status != JBLUETOOTH_TRUE) {
				fprintf(stderr, "Problems starting inquiry!\n");
				success = JBLUETOOTH_FALSE;
			}
		}
	}

	return success;
}


static int create_worker_thread() {
	int status;

	worker_stay_alive = JBLUETOOTH_TRUE;

	status = pthread_create(&worker, NULL, (void*)workerCode, NULL);
	if(status != 0) {
		perror("pthread_create");
		return JBLUETOOTH_FALSE;
	}

	return JBLUETOOTH_TRUE;
}


static int destroy_worker_thread() {
	int success = JBLUETOOTH_TRUE;
	int status = JBLUETOOTH_TRUE;

	worker_stay_alive = JBLUETOOTH_FALSE;

	status = wake_worker();
	if(status != JBLUETOOTH_TRUE) {
		printf("Could not wake worker thread!\n");
		success = JBLUETOOTH_FALSE;
	}

	if(success == JBLUETOOTH_TRUE) {
		sleep(1); /* Give worker time to end ... */
	}

	return success;
}


int event_init() {
	int success = JBLUETOOTH_TRUE;
	int status = JBLUETOOTH_TRUE;

	if(success == JBLUETOOTH_TRUE) {
		status = block_init();
		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "Could not init block!\n");
			success = JBLUETOOTH_FALSE;
		}
	}

	if(success == JBLUETOOTH_TRUE) {
		status = create_locks();
		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "Could not create locks!");
			success = JBLUETOOTH_FALSE;
		}
	}

	if(success == JBLUETOOTH_TRUE) {
		status = create_worker_thread();
		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "Could not create worker thread!\n");
			success = JBLUETOOTH_FALSE;
		}
	}

	return success;
}


int event_destroy() {
	int success = JBLUETOOTH_TRUE;
	int status = JBLUETOOTH_TRUE;

	status = block_destroy();
	if(status != JBLUETOOTH_TRUE) {
		fprintf(stderr, "Problems with deinit block!\n");
		success = JBLUETOOTH_FALSE;
	}

	status = destroy_worker_thread();
	if(status != JBLUETOOTH_TRUE) {
		fprintf(stderr, "Could not destory worker thread!\n");
		success = JBLUETOOTH_FALSE;
	}

	status = destroy_locks();
	if(status != JBLUETOOTH_TRUE) {
		fprintf(stderr, "Could not destroy locks!\n");
	}

	return success;
}


int event_startInquiry(int accessCode, DiscoveryListener listener) {
	int success = JBLUETOOTH_TRUE;
	int status = JBLUETOOTH_TRUE;

	status = obtain_data_lock();
	if(status != JBLUETOOTH_TRUE) {
		fprintf(stderr, "Could not obtain data lock!\n");
		success = JBLUETOOTH_FALSE;
	}

	if(success == JBLUETOOTH_TRUE) {
		shared_accessCode = accessCode;
		shared_listener = listener;

		status = release_data_lock();
		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "Could not release data lock!\n");
			success = JBLUETOOTH_FALSE;
		}
	}

	if(success == JBLUETOOTH_TRUE) {
		status = wake_worker();
		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "Could not wake worker!\n");
			success = JBLUETOOTH_FALSE;
		}
	}

	return success;
}


int event_cancelInquiry(DiscoveryListener listener) {
	return block_cancelInquiry(listener);
}
