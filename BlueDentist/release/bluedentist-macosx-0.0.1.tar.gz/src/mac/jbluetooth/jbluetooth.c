#include "jbluetooth.h"
#include "event.h"


int jbluetooth_init() {
	return event_init();
}


int jbluetooth_destroy() {
	return event_destroy();
}


int jbluetooth_startInquiry(int accessCode, DiscoveryListener listener) {
	int success = JBLUETOOTH_TRUE;
	int status = JBLUETOOTH_TRUE;

	if(success == JBLUETOOTH_TRUE) {
		status = event_startInquiry(accessCode, listener);
		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "could not start inquiry!\n");
			success = JBLUETOOTH_FALSE;
		}
	}

	return success;
}


int jbluetooth_cancelInquiry(DiscoveryListener listener) {
	return event_cancelInquiry(listener);
}
