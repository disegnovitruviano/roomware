#include <jniutil.h>
#include <jbluetooth.h>

#define BLUETOOTH_ADDRESS_LENGTH	13
#define BLUETOOTH_ADDRESS_UINT8_DIGITS	6

static DiscoveryListener discoveryListener;
static DiscoveryListener_t discoveryListenerRaw;
static jobject myJavaObjectReference;


static void myDeviceDiscovered(IOBluetoothDeviceRef deviceRef, BluetoothClassOfDevice classOfDevice) {
	jint success = true;
	int status;
	const BluetoothDeviceAddress *address;
	char cAddressString[BLUETOOTH_ADDRESS_LENGTH];
	jstring javaAddressString;
	JNIEnv *env;
	int i;

	if(myJavaObjectReference == NULL) {
		fprintf(stderr, "I don't have a pointer to my Java object!\n");
		success = false;
	}
	
	if(success == true) {
		address = IOBluetoothDeviceGetAddress(deviceRef);

		for(i = 0; i < BLUETOOTH_ADDRESS_UINT8_DIGITS; i++) {
			status = snprintf(cAddressString + i * 2, 3, "%.2hx", address->data[i]);
			if(status >= 3) {
				perror("bluetooth address convert");
				success = false;
			}
		}
	}

	if(success == true) {
		env = jniutil_getThisThreadEnv();
		if(env == NULL) {
			fprintf(stderr, "Could not get this thread env!\n");
			success = false;
		}
	}

	if(success == true) {
		javaAddressString = (*env)->NewStringUTF(env, cAddressString);
		if(javaAddressString == NULL) {
			fprintf(stderr, "Could not construct java string!\n");
			success = false;
		}
	}

	if(success == true) {
		status = jniutil_invokeVoidMethod(env, myJavaObjectReference,
			"javax/bluetooth/jni/NativeDiscoveryAgent",
			"deviceDiscovered",
			"(IILjava/lang/String;)V",
			(jint) deviceRef, (jint) classOfDevice,
			javaAddressString);
		if(status != JNIUTIL_TRUE) {
			fprintf(stderr, "Could not invoke deviceDiscovered method!\n");
			success = false;
		}
	}
}


static void myInquiryCompleted(int discType) {
	jint success = true;
	int status;
	JNIEnv *env;

	if(myJavaObjectReference == NULL) {
		fprintf(stderr, "I don't have a pointer to my Java object!\n");
		success = false;
	}

	if(success == true) {
		env = jniutil_getThisThreadEnv();
		if(env == NULL) {
			fprintf(stderr, "I could not fetch my JNIEnv!\n");
			success = false;
		}
	}

	if(success == true) {
		status = jniutil_invokeVoidMethod(env, myJavaObjectReference,
			"javax/bluetooth/jni/NativeDiscoveryAgent",
			"inquiryCompleted", "(I)V",
			(jint) discType);
		if(status != JNIUTIL_TRUE) {
			fprintf(stderr, "Could not invoke inquiryCompleted method!\n");
			success = false;
		}
	}

	if(success == true) {
		(*env)->DeleteGlobalRef(env, myJavaObjectReference);
	}
}


static void initDiscoveryListener() {
	discoveryListenerRaw.deviceDiscovered = myDeviceDiscovered;
	discoveryListenerRaw.inquiryCompleted = myInquiryCompleted;
	discoveryListenerRaw.id = (int)&discoveryListenerRaw;
	discoveryListener = (DiscoveryListener)&discoveryListenerRaw;
}


JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *jvm, void *reserved) {
	jboolean success = true;
	int status;

	initDiscoveryListener();

	if(success == true) {
		status = jniutil_init(jvm);
		if(status != JNIUTIL_TRUE) {
			fprintf(stderr, "Failed to init the jniutil lib!\n");
			success = false;
		}
	}

	if(success == true) {
		status = jbluetooth_init();
		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "Failed to init the jbluetooth lib!\n");
			success = false;
		}
	}

	return (success == true)? jniutil_getRequiredJavaVersion(): -1;
}


JNIEXPORT void JNI_OnUnload(JavaVM *jvm, void *reserved) {
	int status;

	status = jbluetooth_destroy();
	if (status != JBLUETOOTH_TRUE) {
		fprintf(stderr, "Could not destroy jbluetooth lib!\n");
	}

	status = jniutil_destroy();
	if (status != JNIUTIL_TRUE) {
		fprintf(stderr, "Could not destroy jniutil lib!\n");
	}
}


JNIEXPORT jboolean JNICALL Java_javax_bluetooth_jni_NativeDiscoveryAgent_startInquiry(JNIEnv *env, jobject this, jint accessCode) {
	int success = true;
	int status;

	if(success == true) {
		myJavaObjectReference = (*env)->NewGlobalRef(env, this);
		if(myJavaObjectReference == NULL) {
			fprintf(stderr, "Could not create new global reference!\n");
			success = false;
		}
	}

	if(success == true) {
		status = jbluetooth_startInquiry((int)accessCode, discoveryListener);
		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "Could not start inquiry!\n");
			success = false;
		}
	}

	return success;
}


JNIEXPORT jboolean JNICALL Java_javax_bluetooth_jni_NativeDiscoveryAgent_cancelInquiry(JNIEnv *env, jobject this) {
	int success = true;
	int status;

	if(success == true) {
		status = jbluetooth_cancelInquiry(discoveryListener);

		if(status != JBLUETOOTH_TRUE) {
			fprintf(stderr, "Failed to cancel inquiry!\n");
			success = false;
		}
	}
	
	return success;
}
