package test;


import javax.bluetooth.*;


public class Test implements DiscoveryListener {

	LocalDevice localDevice;
	DiscoveryAgent discoveryAgent;
	boolean discoveryCompleted = false;


	public Test() throws BluetoothStateException {
		localDevice = LocalDevice.getLocalDevice();
		discoveryAgent = localDevice.getDiscoveryAgent();
	}


	public void start() throws BluetoothStateException {
		discoveryAgent.startInquiry(DiscoveryAgent.GIAC, this);
		System.out.println("Inquiry started!");

		synchronized (this) {
			try {
				wait(20000);
			}

			catch(InterruptedException cause) {
			}

			if(!discoveryCompleted) {
				discoveryAgent.cancelInquiry(this);
			}
		}
	}


	public void deviceDiscovered(RemoteDevice btDevice, DeviceClass clazz) {
		System.out.println(btDevice.getBluetoothAddress());
	}


	public void inquiryCompleted(int discType) {
		synchronized(this) {
			discoveryCompleted = false;
			notify();
		}

		System.out.println("Inquiry completed!");
	}


	public static void main(String args[]) throws Exception {
		new Test().start();
	}

}
