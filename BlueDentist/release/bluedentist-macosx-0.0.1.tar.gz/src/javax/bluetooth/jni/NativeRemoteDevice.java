package javax.bluetooth.jni;


import javax.bluetooth.*;



public class NativeRemoteDevice extends RemoteDevice {

		private int nativeDeviceRef;


		public NativeRemoteDevice(int nativeDeviceRef, String address) {
			super(address);
			this.nativeDeviceRef = nativeDeviceRef;
		}


		int getNativeDeviceRef() {
			return nativeDeviceRef;
		}

}
