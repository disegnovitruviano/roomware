package javax.bluetooth.jni;


import javax.bluetooth.*;
import java.io.*;


public class NativeLocalDevice extends LocalDevice {

	static {
		System.loadLibrary("bluedentist");
	}

	private static NativeLocalDevice nativeLocalDevice = null;


	private NativeLocalDevice() throws BluetoothStateException {
		/* TODO: check some stuff */
	}


	public static LocalDevice getLocalDevice() throws BluetoothStateException {
		if(nativeLocalDevice == null) {
			nativeLocalDevice = new NativeLocalDevice();
		}

		return nativeLocalDevice;
	}


	public DiscoveryAgent getDiscoveryAgent() {
		return NativeDiscoveryAgent.getDiscoveryAgent();
	}

}
